//
//  ViewController.swift
//  SamplePractice
//
//  Created by Malleboina,Meghanaa on 1/26/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var course1Outlet: UITextField!
    
    @IBOutlet weak var course2Outlet: UITextField!
    
    @IBOutlet weak var displaylabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }


    @IBAction func submitButton(_ sender: Any) {
        //Read the first course name and store it in a variable
        //Read the second course name and store it in a variable
        //Perform the concatenation and assign it to display label
        var input1 = course1Outlet.text!
        var input2 = course2Outlet.text!
        displaylabel.text = "\(input1) - \(input2)"
    }
}

