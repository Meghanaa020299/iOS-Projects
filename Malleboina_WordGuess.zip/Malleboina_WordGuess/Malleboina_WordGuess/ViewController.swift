//
//  ViewController.swift
//  Malleboina_WordGuess
//
//  Created by Malleboina,Meghanaa on 3/29/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var guessLetter: UIButton!
    
    @IBOutlet weak var playAgain: UIButton!
    
    
    @IBOutlet weak var hintLabel: UILabel!
    
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var displayImage: UIImageView!
    
    var words = [["GOLD", "Ornament"],
                 ["AMAZON", "ecommerce website"],
                 ["RICE", "Food"],
                 ["SHIRT", "Cloth"],
                 ["PRABHAS", "Actor"]]
    var images = [["gold"],
                  ["amazon"],
                  ["rice"],
                  ["shirt"],
                  ["prabhas"]]
    var count = 0;
    var word = ""
    var lettersGuessed = ""
    var img_num = 0
    var a = 0
    var b = 5
    var c = 0
    //var temp = 0
    let maxNumOfWrongGuesses = 10
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //check button should be disabled
        guessLetter.isEnabled = false
        playAgain.isHidden = true
        word = words[count][0]
        userGuessLabel.text = ""
        updateUnderscores();
        hintLabel.text = "Hint: "+words[count][1]
        statusLabel.text = ""
        wordsGuessedLabel.text = wordsGuessedLabel.text! + "\(a)"
        wordsRemainingLabel.text = wordsRemainingLabel.text! + "\(b)"
        totalWordsLabel.text = totalWordsLabel.text! + "5"
        guessCountLabel.text = "You have made " + "\(c)" + " guesses"
        
    }
    
    @IBAction func guessLetterButtonPressed(_ sender: Any) {
        
        c += 1
        var letter = guessLetterField.text!
        lettersGuessed = lettersGuessed + letter
        var revealedWord = ""
        for l in word{
            if lettersGuessed.contains(l){
                revealedWord += "\(l)"
            }
            else{
                revealedWord += "_ "
            }
        }
        
         userGuessLabel.text = revealedWord
        guessLetterField.text = ""
        guessCountLabel.text = "You have made " + "\(c)" + " guesses"
        if c > maxNumOfWrongGuesses {
            guessCountLabel.text = "You have used all the available guesses, please play again"
            playAgain.isHidden = false
            count -= 1
            img_num -= 1
        }
        
        
        if userGuessLabel.text!.contains("_") == false{
            //a = 0
            playAgain.isHidden = false;
            guessLetter.isEnabled = false;
            
            displayImage.image = UIImage(named: images[img_num][0])
            wordsGuessedLabel.text = wordsGuessedLabel.text! + ""
            a += 1
            b -= 1
            wordsGuessedLabel.text = "Total number of words guessed successfully: " + "\(a)"
            wordsRemainingLabel.text = "Total number of words remaining in game:" + "\(b)"
            guessCountLabel.text = "Wow! You have made \(c) guesses to guess the word "
        }
        guessLetter.isEnabled = false
    }
    
    @IBAction func playAgainButtonPressed(_ sender: Any) {
        
        playAgain.isHidden = true
        lettersGuessed = ""
        count += 1
        
        img_num += 1
        
        if count == words.count{
            
            statusLabel.text = "Congrualtions! You are done with the game!"
            userGuessLabel.text = ""
            hintLabel.text = ""
            guessCountLabel.text = ""
            playAgain.isHidden = false
            displayImage.image = UIImage(named: "alldone")
        }
        else{
            if(count >= 6) {
               count = 0
                img_num = 0
                a = 0
                b = 5
                wordsGuessedLabel.text = "Total number of words guessed successfully: " + "\(a)"
                wordsRemainingLabel.text = "Total number of words remaining in game:" + "\(b)"
                statusLabel.text = ""
            }
            word = words[count][0]
            hintLabel.text = "Hint: "
            hintLabel.text! += words[count][1]
            guessLetter.isEnabled = true
            displayImage.image = UIImage(named: "")
            userGuessLabel.text = ""
            updateUnderscores()
            c = 0
            guessCountLabel.text = "You have made " + "\(c)" + " guesses"
        }
        if c > maxNumOfWrongGuesses {
            count += 0
        }
    }
    
    @IBAction func guessLetterAction(_ sender: Any) {
        
        var textEnterd = guessLetterField.text!;
        textEnterd = String(textEnterd.last ?? " ").trimmingCharacters(in: .whitespaces)
        guessLetterField.text = textEnterd
        
        //Check whether the entered text is empty or not to enable check button.
        if textEnterd.isEmpty{
            guessLetter.isEnabled = false
        }
        else{
            guessLetter.isEnabled = true
        }
    }
    func updateUnderscores(){
        for letter in word{
            userGuessLabel.text! += "- "
        }
    }
}

