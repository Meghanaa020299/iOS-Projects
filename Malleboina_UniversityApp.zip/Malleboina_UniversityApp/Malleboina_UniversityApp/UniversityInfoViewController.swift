//
//  UniversityInfoViewController.swift
//  Malleboina_UniversityApp
//
//  Created by Malleboina,Meghanaa on 4/17/23.
//

import UIKit

class UniversityInfoViewController: UIViewController {

    var uInfo = UniversityList()
    
    @IBOutlet weak var universityImageViewOutlet: UIImageView!
    
    
    @IBOutlet weak var universityInfoOutlet: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //universityInfoOutlet.text = uInfo.collegeInfo
        universityInfoOutlet.isHidden = true
        self.title = uInfo.collegeName
        universityImageViewOutlet.frame.origin.x = view.frame.maxX
        universityImageViewOutlet.image = UIImage(named: uInfo.collegeImage)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration: 1){
            self.universityImageViewOutlet.center.x = self.view.center.x
        }
    }
   

    @IBAction func showInfoAction(_ sender: Any) {
        //universityInfoOutlet.isHidden = false
        universityInfoOutlet.text = uInfo.collegeInfo
        universityInfoOutlet.isHidden = false
    }
  
    
}
