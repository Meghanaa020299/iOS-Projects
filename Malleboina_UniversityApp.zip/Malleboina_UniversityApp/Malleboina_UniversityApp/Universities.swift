//
//  Universities.swift
//  Malleboina_UniversityApp
//
//  Created by Malleboina,Meghanaa on 4/18/23.
//

import Foundation

struct Universities  {
    var domain  = ""
    var list_Array:[UniversityList] = []
}
struct UniversityList {
    var collegeName = ""
    var collegeImage = ""
    var collegeInfo = ""
}
let Univerisity1 = Universities(domain: "Information Technology",
                                list_Array: [UniversityList(collegeName: "Northwest Missouri State University",
                                                            collegeImage: "nwmsu",collegeInfo: "Northwest Missouri State University is a public university in Maryville, Missouri. It has an enrollment of about 8,505 students."),
                                             UniversityList(collegeName:"University of Central Missouri",
                                                            collegeImage: "ucm",collegeInfo: "The University of Central Missouri is a public university in Warrensburg, Missouri. In 2019, enrollment was 11,229 students from 49 states and 59 countries"),
                                             UniversityList(collegeName: "George Mason University",
                                                            collegeImage: "gmu",collegeInfo: "George Mason University is a public research university in Fairfax County, Virginia, with an independent City of Fairfax postal address in the Washington metropolitan area."),
                                             UniversityList(collegeName: "University of Texas at Dallas",
                                                            collegeImage: "utd",collegeInfo: "The University of Texas at Dallas is a public research university in Richardson, Texas. It is one of the largest public universities in the Dallas area and the northernmost institution of the University of Texas system"),
                                             UniversityList(collegeName: "University of South Florida",
                                                            collegeImage: "usf",collegeInfo: "The University of South Florida is a public research university with its main campus located in Tampa, Florida, and other campuses in St. Petersburg and Sarasota.")])

let University2 = Universities(domain: "Computer Science",
                                list_Array: [UniversityList(collegeName: "Michigan Technological University",
                                                            collegeImage: "mtu",collegeInfo: "Michigan Technological University is a public research university in Houghton, Michigan, founded in 1885 as the Michigan Mining School, the first post-secondary institution in the Upper Peninsula of Michigan"),
                                             UniversityList(collegeName:"Arizona State University",
                                                            collegeImage: "asu",collegeInfo: "Arizona State University is a public research university in the Phoenix metropolitan area. Founded in 1885 by the 13th Arizona Territorial Legislature,"),
                                             UniversityList(collegeName: "The University of California, Los Angeles",
                                                            collegeImage: "ucla",collegeInfo: "The University of California, Los Angeles, is a public land-grant research university in Los Angeles, California. UCLA's academic roots were established in 1881"),
                                             UniversityList(collegeName: "Florida International University",
                                                            collegeImage: "fiu",collegeInfo: "Florida International University is a public research university with its main campus in the neighborhood of University Park in the Westchester census-designated place in the unincorporated area of West End in Miami-Dade County, Florida"),
                                             UniversityList(collegeName: "New Jersey Institute of Technology",
                                                            collegeImage: "njit",collegeInfo: "New Jersey Institute of Technology is a public research university in Newark, New Jersey with a graduate-degree-granting satellite campus in Jersey City")])

let University3 = Universities(domain: "Data Science And Analytics",
                                list_Array: [UniversityList(collegeName: "The University of North Texas",
                                                            collegeImage: "unt",collegeInfo: "The University of North Texas is a public research university in Denton, Texas. It was founded as a nonsectarian, coeducational, private teachers college in 1890 "),
                                             UniversityList(collegeName:"Texas Tech University",
                                                            collegeImage: "ttu",collegeInfo: "Texas Tech University is a public research university in Lubbock, Texas. Established on February 10, 1923, and called Texas Technological College until 1969"),
                                             UniversityList(collegeName: "The University of Houston",
                                                            collegeImage: "uh",collegeInfo: "The University of Houston is a public research university in Houston, Texas. Founded in 1927, UH is a member of the University of Houston System"),
                                             UniversityList(collegeName: "Texas A&M University",
                                                            collegeImage: "atm",collegeInfo: "Texas A&M University is a public, land-grant, research university in College Station, Texas. It was founded in 1876 "),
                                             UniversityList(collegeName: "Baylor University",
                                                            collegeImage: "bu",collegeInfo: "Baylor University is a private Baptist Christian research university in Waco, Texas. Baylor was chartered in 1845 by the last Congress of the Republic of Texas")])

let University4 = Universities(domain: "Cyber Security",
                                list_Array: [UniversityList(collegeName: "The University of Texas at Austin",
                                                            collegeImage: "uta",collegeInfo: "The University of Texas at Austin is a public research university in Austin, Texas, and the flagship institution of the University of Texas System"),
                                             UniversityList(collegeName:"The University of North Texas",
                                                            collegeImage: "unt",collegeInfo: "The University of North Texas is a public research university in Denton, Texas. It was founded as a nonsectarian, coeducational, private teachers college in 1890"),
                                             UniversityList(collegeName: "New Jersey Institute of Technology",
                                                            collegeImage: "njit",collegeInfo: "New Jersey Institute of Technology is a public research university in Newark, New Jersey with a graduate-degree-granting satellite campus in Jersey City"),
                                             UniversityList(collegeName: "University of Texas at Dallas",
                                                            collegeImage: "utd",collegeInfo: "The University of Texas at Dallas is a public research university in Richardson, Texas. It is one of the largest public universities in the Dallas area and the northernmost institution of the University of Texas system"),
                                             UniversityList(collegeName: "University of South Florida",
                                                            collegeImage: "usf",collegeInfo: "The University of South Florida is a public research university with its main campus located in Tampa, Florida, and other campuses in St. Petersburg and Sarasota.")])
let uList:[Universities] = [Univerisity1,University2,University3,University4]
