//
//  UniversityListViewController.swift
//  Malleboina_UniversityApp
//
//  Created by Malleboina,Meghanaa on 4/17/23.
//

import UIKit


class UniversityListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var universityListTableView: UITableView!
    
    
    var uni1 = Universities()
    override func viewDidLoad() {
        super.viewDidLoad()

        universityListTableView.delegate = self
        universityListTableView.dataSource = self
        self.title = uni1.domain
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return uni1.list_Array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Create a cell
        let myCell1 = universityListTableView.dequeueReusableCell(withIdentifier: "listCell", for: indexPath)
        //Populate a cell
        myCell1.textLabel?.text = uni1.list_Array[indexPath.row].collegeName
        //return a cell
        return myCell1
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "universityInfoSegue"{
            let destination = segue.destination as! UniversityInfoViewController
            destination.uInfo = uni1.list_Array[(universityListTableView.indexPathForSelectedRow?.row)!]
        }
    }
}
