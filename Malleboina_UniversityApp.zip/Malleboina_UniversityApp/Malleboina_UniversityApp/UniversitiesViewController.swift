//
//  ViewController.swift
//  Malleboina_UniversityApp
//
//  Created by Malleboina,Meghanaa on 4/17/23.
//

import UIKit
 
    class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
        
        
        
        
        @IBOutlet weak var universitiesTableView: UITableView!
        
        var uni = uList
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
            universitiesTableView.delegate = self
            universitiesTableView.dataSource = self
            
            self.title = "Domain"
        }
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return uni.count
        }
        
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            //Create a cell
            let myCell = universitiesTableView.dequeueReusableCell(withIdentifier: "domainCell", for: indexPath)
            //Populate a cell
            myCell.textLabel?.text = uni[indexPath.row].domain
            //return a cell
            return myCell
        }
    
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let transition = segue.identifier
            if transition == "listsSegue" {
                let destination = segue.destination as! UniversityListViewController
                
                //send the selected product row
                destination.uni1 = uni[(universitiesTableView.indexPathForSelectedRow?.row)!]
            }
        }
    
}
