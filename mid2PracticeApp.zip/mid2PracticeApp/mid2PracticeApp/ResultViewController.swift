//
//  ResultViewController.swift
//  mid2PracticeApp
//
//  Created by Malleboina,Meghanaa on 4/10/23.
//

import UIKit

class ResultViewController: UIViewController {

    
    @IBOutlet weak var heightLabel: UILabel!
    
    @IBOutlet weak var weightLabel: UILabel!
    
    @IBOutlet weak var BMILabel: UILabel!
    
    var ht = ""
    var wt = ""
    var bmi = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        heightLabel.text! += ht
        weightLabel.text! += wt
        BMILabel.text! += bmi
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
