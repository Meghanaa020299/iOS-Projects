//
//  ThirdViewController.swift
//  mid2PracticeApp
//
//  Created by Malleboina,Meghanaa on 4/10/23.
//

import UIKit

class ThirdViewController: UIViewController {

    
    @IBOutlet weak var imgView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //imgView.frame.origin.x = 400
        imgView.frame = CGRect(x: 400, y: 200, width: 150, height: 150)
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration: 4.0, delay: 0.1) {
            self.imgView.frame.origin.x = 20
        }
    }
    
    
    @IBAction func shakeme(_ sender: UIButton) {
        imgView.frame = CGRect(x: 20, y: 200, width: 250, height: 250)
//        UIView.animate(withDuration: 2.0, delay: 0.1) {
//            self.imgView.frame = CGRect(x: 20, y: 200, width: 150, height: 150)
//        }
        
        
        UIView.animate(withDuration: 2.0, delay: 0.1, usingSpringWithDamping: 0.4, initialSpringVelocity: 0.8) {
            self.imgView.frame = CGRect(x: 20, y: 200, width: 150, height: 150)
        }
    }
    
    
    


}
