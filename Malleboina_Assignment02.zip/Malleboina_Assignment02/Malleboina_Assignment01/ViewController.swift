//
//  ViewController.swift
//  Malleboina_Assignment01
//
//  Created by Malleboina,Meghanaa on 1/30/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstNameOutlet: UITextField!
    
    @IBOutlet weak var lastNameOutlet: UITextField!
    
    @IBOutlet weak var yearOutlet: UITextField!
    
    @IBOutlet weak var fullNameLabel: UILabel!
    
    @IBOutlet weak var initialsLabel: UILabel!
    

    @IBOutlet weak var ageLabel: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    @IBAction func SubmitBTN(_ sender: UIButton) {
        var input1 :String = firstNameOutlet.text!
        var input2:String = lastNameOutlet.text!
        var input3:Int = Int(yearOutlet.text!)!
        fullNameLabel.text = "Full Name : "+lastNameOutlet.text!+" "+firstNameOutlet.text!
        initialsLabel.text = "Intials : "+input1.first!.uppercased()+" "+input2.first!.uppercased()
        let year = Calendar.current.component(.year, from: Date())
    ageLabel.text="Age : "+String(year-input3)
    }
    
    

    @IBAction func ResetBTN(_ sender: UIButton) {
        fullNameLabel.text=""
        initialsLabel.text=""
        ageLabel.text=""
        firstNameOutlet.text=""
        lastNameOutlet.text=""
        yearOutlet.text=""
        
    }
}

