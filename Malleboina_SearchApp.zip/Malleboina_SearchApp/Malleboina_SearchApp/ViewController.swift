//
//  ViewController.swift
//  Malleboina_SearchApp
//
//  Created by Malleboina,Meghanaa on 3/22/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var SearchButton: UIButton!
    
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var PreviousButton: UIButton!
    
    
    @IBOutlet weak var ResetButton: UIButton!
    
    @IBOutlet weak var NextButton: UIButton!
    
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    var arr1 = [["dog","cat","lion","rabbit","tiger"],["rose","lily","jasmine","tulip","sunflower"],["prabhas","jrntr","surya","alluarjun","dulquer"]]
    
    var animals_keywords = ["carnivore","herbivore","wild","zoo","prey"]
    var flowers_keywords = ["pollination","florals","garland","flower","petals"]
    var actors_keywords = ["actor","action","movie","acting","performance"]
    var topic = 0
    var img_num = 0
    
    var arr2 = [["The dog (Canis familiaris or Canis lupus familiaris is a domesticated descendant of the wolf. Also called the domestic dog, it is derived from the extinct Pleistocene wolf,and the modern wolf is the dog's nearest living relative.","The cat (Felis catus) is a domestic species of small carnivorous mammal.It is the only domesticated species in the family Felidae and is commonly referred to as the domestic cat or house cat to distinguish it from the wild members of the family.","The lion (Panthera leo) is a large cat of the genus Panthera native to Africa and India. It has a muscular, broad-chested body; short, rounded head; round ears; and a hairy tuft at the end of its tail. It is sexually dimorphic; adult male lions are larger than females and have a prominent mane.","Rabbits, also known as bunnies or bunny rabbits, are small mammals in the family Leporidae (which also contains the hares) of the order Lagomorpha (which also contains the pikas). Oryctolagus cuniculus includes the European rabbit species and its descendants, the world's 305 breeds of domestic rabbit.","The tiger (Panthera tigris) is the largest living cat species and a member of the genus Panthera. It is most recognisable for its dark vertical stripes on orange fur with a white underside. An apex predator, it primarily preys on ungulates, such as deer and wild boar."],
                ["Roses are best known as ornamental plants grown for their flowers in the garden and sometimes indoors. They have been also used for commercial perfumery and commercial cut flower crops.","Lilies are tall perennials ranging in height from 2–6 ft (60–180 cm). They form naked or tunicless scaly underground bulbs which are their organs of perennation.","Jasmine can be either deciduous (leaves falling in autumn) or evergreen (green all year round), and can be erect, spreading, or climbing shrubs and vines. Their leaves are borne in opposing or alternating arrangement and can be of simple, trifoliate, or pinnate formation.","Tulips (Tulipa) are a genus of spring-blooming perennial herbaceous bulbiferous geophytes (having bulbs as storage organs). The flowers are usually large, showy and brightly coloured, generally red, pink, yellow, or white (usually in warm colours)","The common sunflower (Helianthus annuus) is a large annual forb of the genus Helianthus. It is commonly grown as a crop for its edible oily seeds. Apart from cooking oil production, it is also used as livestock forage (as a meal or a silage plant), as bird food"],
                ["Uppalapati Venkata Suryanarayana Prabhas Raju (born 23 October 1979), known mononymously as Prabhas, is an Indian actor who works predominantly in Telugu cinema. One of the highest-paid actors in Indian cinema","Nandamuri Taraka Rama Rao Jr. (born 20 May 1983), also known as Jr NTR or Tarak, is an Indian actor who primarily works in Telugu cinema. One of the highest paid Telugu film actors, Rama Rao Jr. has won several accolades, including two Filmfare Awards","Saravanan Sivakumar (born 23 July 1975), known by his stage name Suriya, is an Indian actor, producer, television presenter and a philanthropist. He primarily works in Tamil cinema ","Allu Arjun made his debut with Gangotri in 2003. He rose to prominence starring in Sukumar's cult classic Arya (2004) for which he earned a Nandi Special Jury Award.","Dulquer Salmaan (born 28 July 1983) is an Indian actor, playback singer and film producer who predominantly works in Malayalam and Tamil films in addition to Telugu and Hindi films."]]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SearchButton.isEnabled = false;
        resultImage.image = UIImage(named: "welcome")
        topicInfoText.isUserInteractionEnabled = false
        topicInfoText.text = ""
        PreviousButton.isHidden = true
        ResetButton.isHidden = true
        NextButton.isHidden = true
        topic = 0
    }
    
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        img_num = 0
        topicInfoText.isUserInteractionEnabled = true
        if(animals_keywords.contains(searchTextField.text!)){
            topic = 1
            PreviousButton.isEnabled = false
            NextButton.isEnabled = true
            PreviousButton.isHidden = false
            ResetButton.isHidden = false
            NextButton.isHidden = false
            resultImage.image = UIImage(named: arr1[0][0])
            topicInfoText.text = arr2[0][0]
        }else if(flowers_keywords.contains(searchTextField.text!)) {
            topic = 2
            PreviousButton.isEnabled = false
            NextButton.isEnabled = true
            PreviousButton.isHidden = false
            ResetButton.isHidden = false
            NextButton.isHidden = false
            resultImage.image = UIImage(named: arr1[1][0])
            topicInfoText.text = arr2[1][0]
            
        }else if(actors_keywords.contains(searchTextField.text!)) {
            topic = 3
            PreviousButton.isEnabled = false
            NextButton.isEnabled = true
            PreviousButton.isHidden = false
            ResetButton.isHidden = false
            NextButton.isHidden = false
            resultImage.image = UIImage(named: arr1[2][0])
            topicInfoText.text = arr2[2][0]
            
        }else {
            resultImage.image = UIImage(named: "oops")
            PreviousButton.isHidden = true
            ResetButton.isHidden = true
            NextButton.isHidden = true
        }
        
        
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: Any) {
        img_num -= 1
        NextButton.isEnabled = true
        PreviousButton.isEnabled = true
        if(topic == 1) {
            resultImage.image = UIImage(named: arr1[0][img_num])
            topicInfoText.text = arr2[0][img_num]
        } else if(topic == 2) {
            resultImage.image = UIImage(named: arr1[1][img_num])
            topicInfoText.text = arr2[1][img_num]
        } else if(topic == 3) {
            resultImage.image = UIImage(named: arr1[2][img_num])
            topicInfoText.text = arr2[2][img_num]
        } else {
            print("")
        }
        if(img_num == 0) {
            PreviousButton.isEnabled = false
        } else {
            PreviousButton.isEnabled = true
        }
    }
    
    @IBAction func ResetBtn(_ sender: Any) {
        searchTextField.text = ""
        img_num = 0
        SearchButton.isEnabled = false;
        resultImage.image = UIImage(named: "welcome")
        topicInfoText.isUserInteractionEnabled = false
        topicInfoText.text = ""
        PreviousButton.isHidden = true
        ResetButton.isHidden = true
        NextButton.isHidden = true
        topic = 0
            
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: Any) {
        img_num += 1
        NextButton.isEnabled = true
        PreviousButton.isEnabled = true
        if(topic == 1) {
            resultImage.image = UIImage(named: arr1[0][img_num])
            topicInfoText.text = arr2[0][img_num]
        } else if(topic == 2) {
            resultImage.image = UIImage(named: arr1[1][img_num])
            topicInfoText.text = arr2[1][img_num]
        } else if(topic == 3) {
            resultImage.image = UIImage(named: arr1[2][img_num])
            topicInfoText.text = arr2[2][img_num]
        } else {
            print("")
        }
        if(img_num == arr1[0].count - 1) {
            NextButton.isEnabled = false
        } else {
            NextButton.isEnabled = true
        }
        
    }
    
    @IBAction func textFieldEditingAction(_ sender: UITextField) {
        
        if searchTextField.text!.isEmpty{
            SearchButton.isEnabled = false
        }else {
            SearchButton.isEnabled = true
        }
    }
    
    
}
