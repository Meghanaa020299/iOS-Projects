//
//  ViewController.swift
//  Malleboina_Exam03
//
//  Created by Malleboina,Meghanaa on 4/27/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        A1.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //returns a cell
              //Create a cell with a cell name and the index path
              var cell = tableOutlet.dequeueReusableCell(withIdentifier: "acell", for: indexPath)
              //Assign the data into the cell
              cell.textLabel?.text = A1[indexPath.row].TourListplace
              return cell
    }
    
    var A1 = Arr
    
    @IBOutlet weak var tableOutlet: UITableView!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        tableOutlet.delegate = self
        tableOutlet.dataSource = self
        title.self = "Tourist Places"
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "asegue"{
            let destination = segue.destination as!  TourViewController
            
            //Assigning product to the destination
            destination.Arr2 = A1[(tableOutlet.indexPathForSelectedRow?.row)!]
        }
    }
}

