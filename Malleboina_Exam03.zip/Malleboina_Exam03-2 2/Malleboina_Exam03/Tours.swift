//
//  Tours.swift
//  Malleboina_Exam03
//
//  Created by Malleboina,Meghanaa on 4/27/23.
//

import Foundation

struct TourList{
    var TourListplace : String
    var TourListimage:String}

let t1 = TourList(TourListplace: "Cosmic Cavern", TourListimage: "cosmic")

let t2 = TourList(TourListplace: "Great Wall of China", TourListimage: "wall")

let t3 = TourList(TourListplace: "Statue of Liberty", TourListimage: "statue")

let t4 = TourList(TourListplace: "Great Smoky Mountains", TourListimage: "great")

let t5 = TourList(TourListplace: "Golden Gate Bridge", TourListimage: "gate")

let Arr = [t1,t2,t3,t4,t5]

