//
//  TourViewController.swift
//  Malleboina_Exam03
//
//  Created by Malleboina,Meghanaa on 4/27/23.
//

import UIKit

class TourViewController: UIViewController {
    
    
    @IBOutlet weak var labelOutlet: UILabel!
    
    
    
    @IBOutlet weak var imageOutlet: UIImageView!
    var Arr2:TourList?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        labelOutlet.text = Arr2?.TourListplace
        imageOutlet.image = UIImage(named: Arr2!.TourListimage)
    }
    

    
    @IBAction func animateBtn(_ sender: Any) {
        updateAndAnimate(Arr2!.TourListimage)
    }
    func updateAndAnimate(_ imageName : String){
        
        //making the current image opaque.
        UIView.animate(withDuration: 2, animations: {
            self.imageOutlet.alpha = 0
        })
        
        //Assign the new image with animation and make it transparent. (alpha = 1)
        
        UIView.animate(withDuration: 2, delay:0.2, animations: {
            self.imageOutlet.alpha = 1
            self.imageOutlet.image = UIImage(named: imageName)
        })
    }
    
}
