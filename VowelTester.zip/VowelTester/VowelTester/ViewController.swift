//
//  ViewController.swift
//  VowelTester
//
//  Created by Malleboina,Meghanaa on 1/31/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var inputOutlet: UITextField!
    
    @IBOutlet weak var displayLabel: UILabel!
    
        override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    
    @IBAction func TestBTN(_ sender: UIButton) {
        
        var input = inputOutlet.text!
        
        if (input.contains("a") || input.contains("e") || input.contains("i") || input.contains("o") || input.contains("u"))
        {
            displayLabel.text! = "The entered \(input) has vowel 😅"
        }
        
        else{
            displayLabel.text! = "The entered \(input) has no vowel 😥"
            
            
        }
    }
}

