//
//  ViewController.swift
//  DiscountApp
//
//  Created by Malleboina,Meghanaa on 2/14/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var amountOutlet: UITextField!
    
    @IBOutlet weak var discountOutlet: UITextField!
    @IBOutlet weak var displayLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    @IBAction func button(_ sender: Any) {
        var input1 = Double(amountOutlet.text!)
        var input2 = Double(discountOutlet.text!)
        
        var input3 = input1! - (input1! * input2!)/100
        displayLabel.text = "Price after discount:$\(input3)"
    }
    


}

