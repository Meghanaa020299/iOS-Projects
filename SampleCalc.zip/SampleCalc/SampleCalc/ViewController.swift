//
//  ViewController.swift
//  SampleCalc
//
//  Created by Malleboina,Meghanaa on 2/2/23.
//

import UIKit

class ViewController: UIViewController {

    var operand1 = -1.1
    var _operator = " "
    var _operand2 = -1.1
    @IBOutlet weak var resultLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func Btn5(_ sender: Any) {
        resultLabel.text = "5"
        if( operand1 == -1.1){
            operand1 = 5
        }
        else{
            _operand2 = 5
        }
    }
    @IBAction func Btnplus(_ sender: Any) {
        resultLabel.text = "+"
        if(_operator == " "){
            _operator = "+"
        }
        else{
            _operator = "-"
        }
    }
    @IBAction func Btn3(_ sender: Any) {
        resultLabel.text = "3"
        if( _operand2 == -1.1){
            _operand2 = 3
        }
        else{
            operand1 = 3
        }

    }
    @IBAction func Btnequals(_ sender: Any) {
        resultLabel.text = "="
        resultLabel.text = "\(operand1 + _operand2)"
    }
}

