//
//  ViewController.swift
//  Malleboina_Exam01
//
//  Created by Malleboina,Meghanaa on 2/28/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var INRinput: UITextField!
    
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var displayLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        img.image = UIImage(named: "default")
    }
    
    @IBAction func USDbutton(_ sender: UIButton) {
        
        var a = Double(INRinput.text!)!
        var res:Double = round((a/82.93)*100)/100
        
        if(INRinput.text == ""){
            img.image = UIImage(named: "oops")
            displayLabel.text = "Please enter some text"
        }else if (a == 0) {
            img.image = UIImage(named: "oops")
            displayLabel.text = "₹ 0.0 Oops! cannot convert"
        }
        else {
            displayLabel.text = "₹\(a) in USD is $\(res)"
            img.image = UIImage(named: "usd")
        }
    }
    
    @IBAction func CADbutton(_ sender: UIButton) {
        var b = Double(INRinput.text!)!
        var res1:Double = round(((b*1.26)/82.93)*100)/100
        
        if(INRinput.text!.isEmpty){
            img.image = UIImage(named: "oops")
        }else if (b == 0) {
            img.image = UIImage(named: "oops")
            displayLabel.text = "₹ 0.0 Oops! cannot convert"
        }
        
        else {
            displayLabel.text = "₹\(b) in CAD is $\(res1)"
            img.image = UIImage(named: "cad")
        }
    }
    
    
}

