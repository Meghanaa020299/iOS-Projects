//
//  ViewController.swift
//  HelloApp
//
//  Created by Malleboina,Meghanaa on 1/24/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOutlet: UITextField!
    
    
    @IBOutlet weak var inputOutlet1: UITextField!
    
    @IBOutlet weak var displayLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func submitButtonClick(_ sender: UIButton) {
        //Read the input from the text field and store it in a variable.
        var input = inputOutlet.text!
        var input1 = inputOutlet1.text!
        //Perform the string interpolation and assign it to the displaLabel
        displayLabel.text = "Hello, \(input) \(input1)! 😁"
        
    }
}

