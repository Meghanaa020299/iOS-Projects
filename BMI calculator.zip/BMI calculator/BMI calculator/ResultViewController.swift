//
//  ResultViewController.swift
//  BMI calculator
//
//  Created by Malleboina,Meghanaa on 4/4/23.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var htoutlet: UILabel!
    
    @IBOutlet weak var wtoutlet: UILabel!
    
    @IBOutlet weak var BMIOutlet: UILabel!
    
    var height = ""
    var weight = ""
    var bmi = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        htoutlet.text = htoutlet.text! + height
        wtoutlet.text = wtoutlet.text! + weight
        BMIOutlet.text = BMIOutlet.text! + bmi
        
        

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
