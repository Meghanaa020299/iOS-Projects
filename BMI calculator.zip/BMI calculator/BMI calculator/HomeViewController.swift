//
//  ViewController.swift
//  BMI calculator
//
//  Created by Malleboina,Meghanaa on 4/4/23.
//

import UIKit

class HomeViewController: UIViewController {

    
    @IBOutlet weak var heightOL: UITextField!
    
    @IBOutlet weak var weightOL: UITextField!
    
    var BMI = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func BMIBtn(_ sender: Any) {
        
        var ht = Double(heightOL.text!)
        var wt = Double(weightOL.text!)
        BMI = wt!/(ht! * ht!)
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "resultSegue" {
            var destination = segue.destination as!  ResultViewController
            
            destination.height = heightOL.text!
            destination.weight = weightOL.text!
            destination.bmi = String(BMI)
            heightOL.text = ""
            weightOL.text = ""
        }
        
    }
}

