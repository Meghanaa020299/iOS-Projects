//
//  ViewController.swift
//  Malleboina_CalculatorApp
//
//  Created by Malleboina,Meghanaa on 2/16/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var resultOutlet: UILabel!
    var operator1 = 0.0
           var operator2 = 0.0
           var operator_ = "+"
           var result = 0.0
           var a = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func ButtonAC(_ sender: UIButton) {
        resultOutlet.text = ""
    }
    @IBAction func ButtonC(_ sender: UIButton) {
        var b = resultOutlet.text!
                        if b.count > 0{
                            resultOutlet.text!.removeLast();
                        }
    }
    @IBAction func Buttonplusminus(_ sender: UIButton) {
        if operator_ == "+"{
                           operator_ = "-"
                       }
                       else {
                           operator_ =  "+"
                       }
            }
    
    @IBAction func Buttondivide(_ sender: UIButton) {
        operator1 = Double(resultOutlet.text!)!
                operator_ = "/"
                resultOutlet.text! = ""
    }
    @IBAction func Button7(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "7";
    }
    @IBAction func Button8(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "8";
    }
    @IBAction func Button9(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "9";
    }
    @IBAction func Buttonmultiply(_ sender: UIButton) {
        operator1 = Double(resultOutlet.text!)!
              operator_ = "*"
              resultOutlet.text! = ""
    }
    @IBAction func Button4(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "4";
    }
    @IBAction func Button5(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "5";
    }
    @IBAction func Button6(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "6";
    }
    @IBAction func Buttonminus(_ sender: UIButton) {
        operator1 = Double(resultOutlet.text!)!
                operator_ = "-"
                resultOutlet.text! = ""
    }
    @IBAction func Button1(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "1";
    }
    @IBAction func Button2(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "2";
    }
    @IBAction func Button3(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "3";
    }
    @IBAction func Buttonplus(_ sender: UIButton) {
        operator1 = Double(resultOutlet.text!)!
                operator_ = "+"
                resultOutlet.text! = ""
                
    }
    @IBAction func Button0(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "0";
    }
    @IBAction func Buttondot(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + ".";
    }
    @IBAction func Buttonmod(_ sender: UIButton) {
        operator1 = Double(resultOutlet.text!)!
                operator_ = "%"
                resultOutlet.text! = ""
    }
    @IBAction func Buttonequals(_ sender: UIButton) {
        operator2 = Double(resultOutlet.text!)!
                        
                        if operator_ == "+" {
                            a = Int(operator1 + operator2)
                            resultOutlet.text = String(a)
                        }
                        else if operator_ == "-" {
                            a = Int(operator1 - operator2)
                            resultOutlet.text = String(a)
                        }
                        else if operator_ == "/"{
                            
                            
                            result = operator1 / operator2
                            
                            if(String(result) == "inf")
                            {
                                resultOutlet.text!="Not a number"
                                
                            }
                            else{
                                result = round(result * 100000) / 100000.0
                                resultOutlet.text = String(result)
                            }
                            
                        }
                        else if operator_ == "*"{
                            a = Int(operator1 * operator2)
                            resultOutlet.text = String(a)
                        }
                        else if operator_ == "%"{
                            result = operator1.truncatingRemainder(dividingBy: operator2)
                            result = round(result * 10) / 10.0
                            resultOutlet.text = String(result)
                        }
    }
    
}

