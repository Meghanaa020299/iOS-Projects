//
//  ViewController.swift
//  Malleboina_Exam02
//
//  Created by Malleboina,Meghanaa on 4/11/23.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var IdOutlet: UITextField!
    
    @IBOutlet weak var statusLabelOutlet: UILabel!
    
    @IBOutlet weak var imageOutlet: UIImageView!
    
    @IBOutlet weak var PhysicianOutlet: UIButton!
    
    
    @IBOutlet weak var ReservationOutlet: UIButton!
    
    var pDetails = PatientDetails()
    var pArray = patientsArray
    var isPatientIdfound = false
    override func viewDidLoad() {
        super.viewDidLoad()
       
        statusLabelOutlet.isHidden = true
        PhysicianOutlet.isEnabled = false
        ReservationOutlet.isEnabled = false
    }

    @IBAction func PhysicianBtn(_ sender: Any) {
    }
    
    @IBAction func ReservationBtn(_ sender: Any) {
    }
    
    @IBAction func IdButton(_ sender: UITextField) {
        PhysicianOutlet.isEnabled = true
        let enteredPId = IdOutlet.text!
        let enteredPName = nameOutlet.text!
        for pId in pArray {
            if enteredPId == pId.patientId {
                pDetails = pId
                isPatientIdfound = true
                PhysicianOutlet.isEnabled = true
                statusLabelOutlet.text = "Patient Id \(IdOutlet.text!) is found"
                statusLabelOutlet.isHidden = false
                
            }
        
        }
    
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "PatientSegue") {
                    let destination = segue.destination as! PatientViewController
            destination.pOutlet = IdOutlet.text!
            destination.pImage = PatientDetails()
                }
    }
}

