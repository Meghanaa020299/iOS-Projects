//
//  PatientViewController.swift
//  Malleboina_Exam02
//
//  Created by Malleboina,Meghanaa on 4/11/23.
//

import UIKit

class PatientViewController: UIViewController {
    
    
    @IBOutlet weak var PatientOL: UILabel!
    
    
    @IBOutlet weak var PatientImgOL: UIImageView!
    
    var pOutlet = ""
    var pImage = PatientDetails()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
}
