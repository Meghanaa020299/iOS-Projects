//
//  ViewController.swift
//  StudentApp
//
//  Created by Malleboina,Meghanaa on 4/4/23.
//

import UIKit

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

