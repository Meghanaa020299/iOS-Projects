//
//  ViewController.swift
//  ClimateApp
//
//  Created by Malleboina,Meghanaa on 2/21/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var temperatureInput: UITextField!
    
    @IBOutlet weak var DisplayImage: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func DisplayButton(_ sender: Any) {
        
        var t = Double(temperatureInput.text!)
        
        
        if(t! < 0) {
            DisplayImage.image = UIImage(named: "snow")
        } else if(t!<20){
            DisplayImage.image = UIImage(named: "cool")
        } else {
            DisplayImage.image = UIImage(named: "sunny")
        }
    }
    


}

