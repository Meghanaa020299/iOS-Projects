//
//  ViewController.swift
//  Malleboina_Movies
//
//  Created by Malleboina,Meghanaa on 4/26/23.
//

import UIKit

class GenreViewController: UIViewController, UITableViewDelegate ,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movie.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = genreTableView.dequeueReusableCell(withIdentifier:  "sectionCell", for: indexPath)
                
                //populate a cell
                cell.textLabel?.text = movie[indexPath.row].category
                
                //return a cell
                return cell
    }
    

    var movie = MList
    @IBOutlet weak var genreTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        genreTableView.dataSource = self
        genreTableView.delegate = self
        title.self = "Movies App"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "movieSegue"{
            let destination = segue.destination as! MoviesViewController
            
            destination.mov2 = movie[(genreTableView.indexPathForSelectedRow?.row)!]
        }
    }


}

