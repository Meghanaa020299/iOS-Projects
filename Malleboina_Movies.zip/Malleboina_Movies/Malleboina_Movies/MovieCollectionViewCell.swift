//
//  MovieCollectionViewCell.swift
//  Malleboina_Movies
//
//  Created by Malleboina,Meghanaa on 4/28/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    
    
    @IBOutlet weak var imageOL: UIImageView!
    
    func assignMovie(with movie: Movie){
            imageOL.image = movie.image
        }
    
}
