//
//  MoviesViewController.swift
//  Malleboina_Movies
//
//  Created by Malleboina,Meghanaa on 4/26/23.
//

import UIKit

class MoviesViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        mov2!.movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = movieCollectionView.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MovieCollectionViewCell
                
        cell.assignMovie(with: mov2!.movies[indexPath.row])
                
                return cell
    }
    
    
    @IBOutlet weak var movieNameLabel: UILabel!
    
    @IBOutlet weak var movieRatingLabel: UILabel!
    
    @IBOutlet weak var movieBoxOfficeLabel: UILabel!
    
    
    @IBOutlet weak var movieYearLabel: UILabel!
    
    
    @IBOutlet weak var moviePlotLabel: UILabel!
    
    
    @IBOutlet weak var movieCastLabel: UILabel!
    
    
    @IBOutlet weak var movieCollectionView: UICollectionView!
    
    
    var mov2:Genre?
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        assignMovieDetails(index: indexPath)
    }
    
    func assignMovieDetails(index: IndexPath){
        movieNameLabel.text = "Movie title: \(mov2!.movies[index.row].title)"
        movieRatingLabel.text = "Movie Rating:\(mov2!.movies[index.row].movieRating)"
        movieBoxOfficeLabel.text = "Box Office Collection:\(mov2!.movies[index.row].boxOffice)"
        moviePlotLabel.text = "Plot:\n\(mov2!.movies[index.row].moviePlot)"
        movieCastLabel.text = "Cast:\n \(mov2!.movies[index.row].cast[0]),\(mov2!.movies[index.row].cast[1])"
        movieYearLabel.text = "Movie Release Year:\(mov2!.movies[index.row].releasedYear)"
        }

    override func viewDidLoad() {
        super.viewDidLoad()
        movieCollectionView.dataSource = self
        movieCollectionView.delegate = self
        
        movieNameLabel.text = "Movie title : \(mov2!.movies[0].title)"
        movieRatingLabel.text = "Movie Rating : \(mov2!.movies[0].movieRating)"
        movieBoxOfficeLabel.text = "Box Office Collection : \(mov2!.movies[0].boxOffice)"
        movieYearLabel.text = "Movie Release Year : \(mov2!.movies[0].releasedYear)"
        moviePlotLabel.text = "Plot : \n\(mov2!.movies[0].moviePlot)"
        movieCastLabel.text = "Cast : \n\(mov2!.movies[0].cast.joined(separator: ", "))"
        
        
        
        title.self = mov2?.category
    
    }
    

   

}
