//
//  MovieData.swift
//  Malleboina_Movies
//
//  Created by Malleboina,Meghanaa on 4/28/23.
//

import Foundation
import UIKit

struct Movie{
    
    var   title:String
    var image:UIImage!
    var releasedYear:String
    var movieRating:String
    var  boxOffice:String
    var  moviePlot:String
    var   cast:[String]
    
}
struct Genre{
    var category:String
    var movies:[Movie]
}

let M1 = Genre(category: "Action", movies:[
   Movie(title: "Avatar: The Way of Water", image: UIImage(named:"ava")!, releasedYear: "2022", movieRating: "7.7", boxOffice: "2.317B", moviePlot: "Jake Sully and Ney'tiri have formed a family and are doing everything to stay together. However, they must leave their home and explore the regions of Pandora. When an ancient threat resurfaces, Jake must fight a difficult war against the humans.", cast:["Sam Worthington" ,"Zoe Saldana", "Sigourney Weaver"]),

Movie(title: "Ready Player One", image:UIImage(named: "rpo")!, releasedYear: "2018", movieRating: "7.4", boxOffice: "592.2M", moviePlot: "In 2045 the planet is on the brink of chaos and collapse, but people find salvation in the OASIS: an expansive virtual reality universe created by eccentric James Halliday.", cast: ["Tye Sheridan","Olivia Cooke"]),

Movie(title: "Tenet", image: UIImage(named: "tenet")!, releasedYear: "2020", movieRating: "7.3", boxOffice: "365.3M", moviePlot: "A secret agent is given a single word as his weapon and sent to prevent the onset of World War III. He must travel through time and bend the laws of nature in order to be successful in his mission.", cast: ["John David Washington","Elizabeth Debicki"]),

Movie(title: "The Northman", image: UIImage(named: "nm")!, releasedYear: "2022", movieRating: "7.1", boxOffice: "69.6M", moviePlot: "Prince Amleth is on the verge of becoming a man when his father is brutally murdered by his uncle, who kidnaps the boy's mother. Two decades later, Amleth is now a Viking who raids Slavic villages. He soon meets a seeress who reminds him of his vow -- save his mother, kill his uncle, avenge his father.", cast: ["Alexander Skarsgård","Nicole Kidman"]),

Movie(title: "Uncharted", image:UIImage(named: "un")!, releasedYear: "2022", movieRating: "6.3", boxOffice: "401.7M", moviePlot: "Treasure hunter Victor  Sullivan recruits street-smart Nathan Drake to help him recover a 500-year-old lost fortune amassed by explorer Ferdinand Magellan. What starts out as a heist soon becomes a globe-trotting, white-knuckle race to reach the prize before the ruthless Santiago Moncada", cast: ["Tom Holland","Sophia Ali"])
])


let M2 = Genre(category: "Horror", movies: [
    
Movie(title: "The Dark and the Wicked", image: UIImage(named: "daw")!, releasedYear: "2020", movieRating: "6.1", boxOffice: "422M", moviePlot: "IPlagued by waking nightmares, two siblings suspect that something evil is taking over their family at an isolated farmhouse.", cast: ["Marin Ireland","Michael Abbott Jr"]),
    
Movie(title: "Scream VI", image:UIImage(named: "sc")!, releasedYear: "2023", movieRating: "6.9", boxOffice: "701.8M", moviePlot: "Four survivors of the Ghostface murders leave Woodsboro behind for a fresh start in New York City. However, they soon find themselves in a fight for their lives when a new killer embarks on a bloody rampage.", cast: ["Jenna Ortega","Melissa Barrera"]),
                                          
                                          
Movie(title: "Us", image:UIImage(named:  "us")!, releasedYear: "2019", movieRating: "6.8", boxOffice: "256.1M", moviePlot: "ccompanied by her husband, son and daughter, Adelaide Wilson returns to the beachfront home where she grew up as a child. Haunted by a traumatic experience from the past, Adelaide grows increasingly concerned that something bad is going to happen", cast: ["Lupita Nyong'o","Winston Duke"]),
                                          
Movie(title: "Truth or Dare", image: UIImage(named: "tod")!, releasedYear: "2018", movieRating: "5.2", boxOffice: "95.3M", moviePlot :"Olivia, Lucas and a group of their college friends travel to Mexico for one last getaway before graduation. While there, a stranger convinces one of the students to play a seemingly harmless game of truth or dare with the others. ", cast:["Lucy Hale","Tyler Posey" ]),
                                          
Movie(title: "Lights Out", image:UIImage(named: "lo")!, releasedYear: "2016", movieRating: "6.3", boxOffice: "148.9M", moviePlot: "When Rebecca (Teresa Palmer) left home, she thought that her childhood fears were behind her. As a young girl growing up, she was never really sure of what was real when the lights went out at night.", cast: ["Teresa Palmer","Gabriel Bateman"])
                                          ])
 
let M3 = Genre(category: "Adventure", movies: [
    Movie(title: "Interstellar", image: UIImage(named: "int")!, releasedYear: "2014", movieRating: "8.6", boxOffice: "701.7M", moviePlot: "In Earth's future, a global crop blight and second Dust Bowl are slowly rendering the planet uninhabitable. Professor Brand (Michael Caine), a brilliant NASA physicist, is working on plans to save mankind by transporting Earth's population to a new home via a wormhole", cast: ["Matthew McConaughey","Anne Hathaway"]),

Movie(title: "Life of Pi", image: UIImage(named: "lop")!, releasedYear: "2012", movieRating: "7.9", boxOffice: "609M", moviePlot: "After deciding to sell their zoo in India and move to Canada, Santosh and Gita Patel board a freighter with their sons and a few remaining animals. Tragedy strikes when a terrible storm sinks the ship", cast: ["Suraj Sharma","Irrfan Khan"]),

Movie(title: "Inception", image: UIImage(named: "inc")!, releasedYear: "2021", movieRating: "7.2", boxOffice: "774.2M", moviePlot: "Dom Cobb (Leonardo DiCaprio) is a thief with the rare ability to enter people's dreams and steal their secrets from their subconscious. His skill has made him a hot commodity in the world of corporate espionage but has also cost him everything he loves", cast: ["Leonardo DiCaprio","oseph Gordon-Levitt"]),

Movie(title: "No Time to Die", image: UIImage(named: "nttd")!, releasedYear:"2018", movieRating: "8.4", boxOffice: "384.3M", moviePlot: "James Bond is enjoying a tranquil life in Jamaica after leaving active service. However, his peace is short-lived as his old CIA friend, Felix Leiter, shows up and asks for help. ", cast: ["Daniel Craig","Rami Malek"]),

    Movie(title: "Black Panther", image: UIImage(named: "bp")!, releasedYear:"2018", movieRating: "7.3", boxOffice: "1.3B", moviePlot: "After the death of his father, T'Challa returns home to the African nation of Wakanda to take his rightful place as king. When a powerful enemy suddenly reappears, T'Challa's mettle as king -- and as Black Panther", cast: ["Chadwick Boseman","Lupita Nyong'o"])
])



let MList = [M1,M2,M3]
