//
//  PatientViewController.swift
//  Malleboina_Exam02
//
//  Created by Malleboina,Meghanaa on 4/11/23.
//

import UIKit

class PatientViewController: UIViewController {

    
    @IBOutlet weak var PatientOL: UILabel!
    
    
    @IBOutlet weak var PatientImgOL: UIImageView!
    
    var pOutlet = ""
    var pImage = PatientDetails()
    override func viewDidLoad() {
        super.viewDidLoad()

        //PatientOL.text =
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
