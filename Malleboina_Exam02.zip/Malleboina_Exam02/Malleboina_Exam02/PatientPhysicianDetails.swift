//
//  PatientPhysicianDetails.swift
//  Malleboina_Exam02
//
//  Created by Malleboina,Meghanaa on 4/11/23.
//

import Foundation

struct PatientDetails {
    var patientId = ""
    var doctorName = ""
    var diseaseName = ""
    var reservation = ""
    var diseaseImage = ""
    var patients:[PatientDetails] = []
}


let p1 = PatientDetails(patientId: "123", doctorName: "Dr. John Robert", diseaseName: "Malaria", reservation: "Yes", diseaseImage: "malaria")
let p2 = PatientDetails(patientId: "987", doctorName: "Dr. Patricia Kayle", diseaseName: "Thyroid", reservation: "No", diseaseImage: "thyroid")
let p3 = PatientDetails(patientId: "456", doctorName: "Dr. Mary James", diseaseName: "Diabetes", reservation: "Yes", diseaseImage: "diabetes")
let p4 = PatientDetails(patientId: "385", doctorName: "Dr. Jacob Miller", diseaseName: "Alzheimer's", reservation: "Yes", diseaseImage: "alzheimers")
let p5 = PatientDetails(patientId: "405", doctorName: "Dr. Harry Connor", diseaseName: "Insomnia", reservation: "No", diseaseImage: "insomnia")


var patientsArray:[PatientDetails] = [p1,p2,p3,p4,p5]

