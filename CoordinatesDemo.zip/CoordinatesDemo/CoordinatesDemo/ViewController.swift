//
//  ViewController.swift
//  CoordinatesDemo
//
//  Created by Malleboina,Meghanaa on 3/23/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageOutlet: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let minX = imageOutlet.frame.minX
        let minY = imageOutlet.frame.minY
        print("(\(minX),\(minY)")
        
        let maxX = imageOutlet.frame.maxX
        let maxY = imageOutlet.frame.maxY
        print("(\(maxX),\(maxY)")
        
        let midX = imageOutlet.frame.midX
        let midY = imageOutlet.frame.midY
        print("(\(midX),\(midY)")
        
        //move the image to the upper left corner.
        imageOutlet.frame.origin.x = 0
        imageOutlet.frame.origin.y = 0
        
        //move the image to the upper right corner.
        imageOutlet.frame.origin.x = 414-100
        imageOutlet.frame.origin.y = 0
        
        //move the image to the lower left corner.
        imageOutlet.frame.origin.x = 0
        imageOutlet.frame.origin.y = 896-100
        
        //move the image to the lower right corner.
        imageOutlet.frame.origin.x = 314
        imageOutlet.frame.origin.y = 896-100
        
        //move the image to the midpoint of the screen.
        imageOutlet.frame.origin.x = (430/2)-50
        imageOutlet.frame.origin.y = (932/2)-50
    }


}

