//
//  ViewController.swift
//  DisplayImage
//
//  Created by Malleboina,Meghanaa on 2/21/23.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func imageButton(_ sender: Any) {
        DisplayOutlet.text = "Captain of 2011 World Cup"
        displayImage.image = UIImage(named: "Dhoni")
    }
    
    @IBOutlet weak var displayImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var DisplayOutlet: UILabel!
    
}

