//
//  ViewController.swift
//  MVCDiscountApp1
//
//  Created by Malleboina,Meghanaa on 3/30/23.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var amountOL: UITextField!
    
    @IBOutlet weak var discountOL: UITextField!
    
    var priceAfterDiscount = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnClicked(_ sender: Any) {
        //read the text label and convert it to Double
        var amount = Double(amountOL.text!)
        print(amount!)
        var discRate = Double(discountOL.text!)
        print(discRate!)
        
        priceAfterDiscount = amount! - (amount!*discRate!/100)
        print(priceAfterDiscount)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // create a transition
        var transition = segue.identifier
        if(transition == "resultSegue") {
            //create a destination
            var destination = segue.destination
               as! ResultViewController
            
            //assign values to resultViewController
            destination.destinationAmount = amountOL.text!
            destination.destinationDiscRate = discountOL.text!
            destination.result = String(priceAfterDiscount)
            
        }
    }
    
}

